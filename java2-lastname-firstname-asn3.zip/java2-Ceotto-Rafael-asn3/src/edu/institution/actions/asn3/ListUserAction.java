//Rafael Ceotto
//CIS2217
//Assignment 3 - LinkedIn File I/O
//2021


package edu.institution.actions.asn3;

import java.util.Scanner;

import edu.institution.UserRepository;
import edu.institution.actions.MenuAction;
import edu.institution.asn2.LinkedInUser;

public class ListUserAction implements MenuAction {

	@Override
	public boolean process(Scanner scanner, UserRepository userRepository, LinkedInUser loggedInUser) {
		// TODO Auto-generated method stub
				
		//This action should retrieve all of the LinkedIn users from the user repository and print each
		//user�s user name to the console. The process method for the action should return true to keep
		//the user signed in.
		
		return true;
	}

}
