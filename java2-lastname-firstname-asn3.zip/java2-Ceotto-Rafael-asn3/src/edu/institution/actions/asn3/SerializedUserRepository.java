//Rafael Ceotto
//CIS2217
//Assignment 3 - LinkedIn File I/O
//2021

package edu.institution.actions.asn3;

import java.util.ArrayList;
import java.util.List;

import edu.institution.UserRepository;
import edu.institution.asn2.LinkedInException;
import edu.institution.asn2.LinkedInUser;

public class SerializedUserRepository implements UserRepository {

	private String filePath;
	private String fileName;
	private List<LinkedInUser> users;
	
	//Remember: to serialize and de-serialize the LinkedInUser class, it (along with its super class)
	//must implement Serializable
	
	@Override
	public void init(String filePath, String fileName) {
		// TODO Auto-generated method stub
		
		
		/*This method should deserialize the data stored at the supplied filePath + fileName location into
		a list of LinkedIn users. If there is no previously saved data, then this method should initialize a
		new list of LinkedIn users. Depending on how you implement this method, you may find that
		the other methods defined on this interface may need access to the supplied filePath, fileName,
		and to the list of LinkedIn users that is created by this method. If that is the case, then it is
		recommended that you set these values as properties on the implementing class. See the
		SerializedUserRepository code snippet below for an example on setting these values as
		properties of the class.*/
		
		
		
		this.filePath = filePath;
		this.fileName = fileName;
		
		// deserialize the list of LinkedIn users and set the list as a property of
		// this class

	}

	@Override
	public void add(LinkedInUser user) throws LinkedInException {
		// TODO Auto-generated method stub
		
		/*This method ensures that the supplied user is ready to be added to the user repository and, if
		so, adds the user to the list of users established from the init method.
		If the user name and user type are not supplied, throw a new LinkedInException with the
		message, �The user name and type are required to add a new user.�
		Valid user types are either �P� for premier or �S� for standard. If the user type is invalid, throw a
		new LinkedInException with the message, �Invalid user type. Valid types are P or S.�
		If the supplied user already exists, throw a new LinkedInException with the message, �A user
		already exists with that user name.�
		If the supplied user is ready to be added, add it to the list and call the saveAll() method to save
		the data.*/
		

	}

	@Override
	public void saveAll() {
		// TODO Auto-generated method stub

		//This method overwrites (serializes) the list of LinkedIn users that was established in the init
		//method to the file system.
	}

	@Override
	public void delete(LinkedInUser user) {
		// TODO Auto-generated method stub
		
		//This method removes the supplied LinkedIn user from the list of LinkedIn users that was
		//established in the init method. This method should call the saveAll() method to persist the
		//deleted data.

	}

	@Override
	public LinkedInUser retrieve(String username) {
		// TODO Auto-generated method stub
		
		//This method returns the LinkedIn user associated with the supplied user name or null if there is
		//no user associated with the supplied user name
		
		return null;
	}

	@Override
	public List<LinkedInUser> retrieveAll() {
		// TODO Auto-generated method stub
		
		//This method returns all LinkedIn users in the repository or an empty list if there are no users in
		//the repository.
		
		return new ArrayList<>();
	}

}
