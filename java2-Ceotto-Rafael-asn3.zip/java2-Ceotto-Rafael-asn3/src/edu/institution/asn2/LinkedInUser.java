//Rafael Ceotto
//CIS2217
//Assignment 3 - LinkedIn File I/O
//2021


package edu.institution.asn2;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class LinkedInUser extends UserAccount implements Comparable<LinkedInUser>, Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -3080292664859634039L;
	private String type;
	private List<LinkedInUser> connections = new ArrayList<>();

	public LinkedInUser(String username, String password) {
		super(username, password);
		
		// TODO Auto-generated constructor stub
	}
	
	@Override
	public void setType(String type) {
		// TODO Auto-generated method stub
		this.type=type;
		
	}

	public String getType() {
		return type;
	}
		
	public void addConnection(LinkedInUser user) throws LinkedInException{
			
		
			if(!connections.contains(user)) {
				
				connections.add(user);
				
			}
			
			else {
			  
				throw new LinkedInException("You are already connected with this user");
			}
			
	}
		
	public void removeConnection(LinkedInUser user) throws LinkedInException{
		
		if(connections.contains(user)) {
			
			connections.remove(user);
			
		}
		
		else {
		  throw new LinkedInException("You are NOT connected with this user");
		}
			
	}
		
	public List<LinkedInUser> getConnections(){
		
		//copy of ArrayList
		return new ArrayList<LinkedInUser>(connections);
	}

	@Override
	public int compareTo(LinkedInUser linkUser) {
		// TODO Auto-generated method stub
		return this.getUsername().compareToIgnoreCase(linkUser.getUsername());
	}

	
}
	

