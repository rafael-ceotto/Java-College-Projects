//Rafael Ceotto
//CIS2217
//Assignment 3 - LinkedIn File I/O
//2021

package edu.institution.asn2;


public abstract class UserAccount {
	
	private String username;
	private String password;
	
	public UserAccount(String username, String password) {
		this.username = username;
		this.password = password;
	}
	
	public String getUsername() {
		return username;
	}
	
	public boolean isPasswordCorrect(String password) {
		return this.password.equals(password);
	}

	@Override
	public String toString() {
		return username;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((username == null) ? 0 : username.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		UserAccount other = (UserAccount) obj;
		if (username == null) {
			if (other.username != null)
				return false;
		} else if (!username.equals(other.username))
			return false;
		return true;
	}
	
	public abstract void setType(String type);
	
	
	
	
	
    

}
