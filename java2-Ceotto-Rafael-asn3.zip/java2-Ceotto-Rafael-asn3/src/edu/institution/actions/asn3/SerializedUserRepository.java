//Rafael Ceotto
//CIS2217
//Assignment 3 - LinkedIn File I/O
//2021

package edu.institution.actions.asn3;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import edu.institution.UserRepository;
import edu.institution.asn2.LinkedInException;
import edu.institution.asn2.LinkedInUser;

public class SerializedUserRepository implements UserRepository {

	private String filePath;
	private String fileName;
	private List<LinkedInUser> users;
	private File file;
	
		
	@Override
	public void init(String filePath, String fileName) {
		// TODO Auto-generated method stub			
		
		this.filePath = filePath;
		this.fileName = fileName;
		this.file = new File(filePath, fileName);		
		
		
		try {
			file.createNewFile();
			
			if(file.exists()) {				
				
				try(BufferedReader readFile = new BufferedReader(new FileReader(file))) {
				    
					for(String line; (line = readFile.readLine()) != null; ) {
						
						
				    }
				    
				}
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 
		
		
		
		// deserialize the list of LinkedIn users and set the list as a property of
		// this class
		// write and read from a binary file = input/output

	}

	@Override
	public void add(LinkedInUser user) throws LinkedInException {
		// TODO Auto-generated method stub
		
		/*This method ensures that the supplied user is ready to be added to the user repository and, if
		so, adds the user to the list of users established from the init method.
		If the user name and user type are not supplied, throw a new LinkedInException with the
		message, �The user name and type are required to add a new user.�
		Valid user types are either �P� for premier or �S� for standard. If the user type is invalid, throw a
		new LinkedInException with the message, �Invalid user type. Valid types are P or S.�
		If the supplied user already exists, throw a new LinkedInException with the message, �A user
		already exists with that user name.�
		If the supplied user is ready to be added, add it to the list and call the saveAll() method to save
		the data.*/
		

	}

	@Override
	public void saveAll() {
		// TODO Auto-generated method stub

		//This method overwrites (serializes) the list of LinkedIn users that was established in the init
		//method to the file system.
	}

	@Override
	public void delete(LinkedInUser user) {
		// TODO Auto-generated method stub
		
		//This method removes the supplied LinkedIn user from the list of LinkedIn users that was
		//established in the init method. This method should call the saveAll() method to persist the
		//deleted data.

	}

	@Override
	public LinkedInUser retrieve(String username) {
		// TODO Auto-generated method stub
		
		//This method returns the LinkedIn user associated with the supplied user name or null if there is
		//no user associated with the supplied user name
		
		return null;
	}

	@Override
	public List<LinkedInUser> retrieveAll() {
		// TODO Auto-generated method stub
		
		//This method returns all LinkedIn users in the repository or an empty list if there are no users in
		//the repository.
		
		return new ArrayList<>();
	}

}
