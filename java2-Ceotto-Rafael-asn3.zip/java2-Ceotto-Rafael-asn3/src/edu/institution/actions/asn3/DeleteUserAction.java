//Rafael Ceotto
//CIS2217
//Assignment 3 - LinkedIn File I/O
//2021


package edu.institution.actions.asn3;

import java.util.Scanner;

import edu.institution.UserRepository;
import edu.institution.actions.MenuAction;
import edu.institution.asn2.LinkedInUser;

public class DeleteUserAction implements MenuAction {

	@Override
	public boolean process(Scanner scanner, UserRepository userRepository, LinkedInUser loggedInUser) {
		// TODO Auto-generated method stub
				
		//(Use the supplied Scanner instance to prompt the user for information. Do not create your
		//own instance of Scanner in any action)
		//� Prompt for the user name to delete. Check if the supplied user name exists in the user
		//list.
		//� If the user does NOT exist, display an error message to the console and re-display the
		//menu.
		//� If the user does exist, prompt for the password of the user being deleted.
		//� If the password is not correct, display an error message to the console and return out of
		//the action.
		//� If the password is correct, call the delete method on the user repository passing the user
		//name.
		//� If the deleted user was the logged in user, then the action should return false to tell the
		//Application Controller to sign out the current user. Otherwise, return true to keep the
		//user signed in
		
		return false;
	}

}
