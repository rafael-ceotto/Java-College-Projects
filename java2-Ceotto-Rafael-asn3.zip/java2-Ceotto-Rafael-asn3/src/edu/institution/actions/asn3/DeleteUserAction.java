//Rafael Ceotto
//CIS2217
//Assignment 3 - LinkedIn File I/O
//2021


package edu.institution.actions.asn3;

import java.util.Scanner;

import edu.institution.ApplicationHelper;
import edu.institution.UserRepository;
import edu.institution.actions.MenuAction;
import edu.institution.asn2.LinkedInException;
import edu.institution.asn2.LinkedInUser;

public class DeleteUserAction implements MenuAction {

	@Override
	public boolean process(Scanner scanner, UserRepository userRepository, LinkedInUser loggedInUser) {
		
			
		
		ApplicationHelper.showMessage("User Name");
		String name = scanner.nextLine();
		
		LinkedInUser ret = userRepository.retrieve(name);
		
		
				
		if(!(ret == null)) {
			try {
				throw new LinkedInException("User name is required to continue");
			} catch (LinkedInException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		} 
		
		ApplicationHelper.showMessage("User Password");
		String pass = scanner.nextLine();
		
		if(ret.isPasswordCorrect(pass) == false) {
			try {
				throw new LinkedInException("Password is incorrect");
			} catch (LinkedInException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		} 		
			
		userRepository.delete(ret);		
		
		
		if(ret.equals(loggedInUser)) {
			return false;

		} else {
			return true;
		}

		
		
	}

}
