//Rafael Ceotto
//CIS2217
//Assignment 3 - LinkedIn File I/O
//2021


package edu.institution.actions.asn3;

import java.util.Scanner;

import edu.institution.ApplicationHelper;
import edu.institution.UserRepository;
import edu.institution.actions.MenuAction;
import edu.institution.asn2.LinkedInException;
import edu.institution.asn2.LinkedInUser;

public class AddUserAction implements MenuAction {

	@Override
	public boolean process(Scanner scanner, UserRepository userRepository, LinkedInUser loggedInUser) {
		// TODO Auto-generated method stub		
		
		ApplicationHelper.showMessage("User Name");
		String name = scanner.nextLine();
		ApplicationHelper.showMessage("User Password");
		String pass = scanner.nextLine();
		ApplicationHelper.showMessage("User Type? P or S");
		String type = scanner.nextLine();
			
		LinkedInUser fUser = new LinkedInUser(name,pass);
		fUser.setType(type);
		try {
			userRepository.add(fUser);
		} catch (LinkedInException e) {
			// TODO Auto-generated catch block
			LinkedInException actionException = new LinkedInException("This action could not be completed. Check again later");

			System.out.println(actionException);
			
		}



		return true;
	}

}
