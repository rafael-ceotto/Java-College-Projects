//Rafael Ceotto
//CIS2217
//Assignment 3 - LinkedIn File I/O
//2021


package edu.institution.actions.asn3;

import java.util.Scanner;

import edu.institution.UserRepository;
import edu.institution.actions.MenuAction;
import edu.institution.asn2.LinkedInUser;

public class AddUserAction implements MenuAction {

	@Override
	public boolean process(Scanner scanner, UserRepository userRepository, LinkedInUser loggedInUser) {
		// TODO Auto-generated method stub
		
		//This action should do the following:
		//(Use the supplied Scanner instance to prompt the user for information. Do not create your
		//own instance of Scanner in any action)
		//� Prompt the user for the user name to add.
		//� prompt the user to enter a password and what type of user he/she is.
		
		//construct a new LinkedInUser, setting the supplied user name, password, and
		//type, and call the add method on the supplied user repository.
		//� If the LinkedInException is thrown, catch it and display the message on
		// from the exception.
		//� Return true to keep the user signed in.
		//The process method for the action should return true to keep the user signed in.
		
		
		return true;
	}

}
